#include <string.h>
#include <pspiofilemgr.h>
#include "game.h"

typedef struct {
    unsigned int magic;
    unsigned int version;
    PlayerProgress progress;
} SaveData;

#define SAVE_MAGIC 0x534F4450

int save_load(void)
{
    SceUID fd;
    SaveData data;
    int bytes;

    sceIoMkdir("ms0:/PSP/SAVEDATA/SUKUNAODG", 0777);
    fd = sceIoOpen(GAME_SAVE_PATH, PSP_O_RDONLY, 0777);
    if (fd < 0)
        return 0;

    memset(&data, 0, sizeof(data));
    bytes = sceIoRead(fd, &data, sizeof(data));
    sceIoClose(fd);

    if (bytes != (int)sizeof(data) ||
        data.magic != SAVE_MAGIC || data.version != 1)
        return 0;

    g_game.progress = data.progress;
    return 1;
}

int save_write(void)
{
    SceUID fd;
    SaveData data;

    memset(&data, 0, sizeof(data));
    data.magic = SAVE_MAGIC;
    data.version = 1;
    data.progress = g_game.progress;

    /* Le dossier Savedata doit exister sur la carte memoire. */
    sceIoMkdir("ms0:/PSP/SAVEDATA/SUKUNAODG", 0777);
    fd = sceIoOpen(GAME_SAVE_PATH,
                   PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
    if (fd < 0)
        return 0;

    if (sceIoWrite(fd, &data, sizeof(data)) != (int)sizeof(data)) {
        sceIoClose(fd);
        return 0;
    }

    sceIoClose(fd);
    return 1;
}
