#include "game.h"

static unsigned int previous_buttons = 0;
static unsigned int current_buttons = 0;

void input_init(void)
{
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    previous_buttons = 0;
    current_buttons = 0;
}

void input_update(void)
{
    previous_buttons = current_buttons;
    sceCtrlReadBufferPositive(&g_game.pad, 1);
    current_buttons = g_game.pad.Buttons;
}

int input_pressed(unsigned int buttons)
{
    return ((current_buttons & buttons) != 0) &&
           ((previous_buttons & buttons) == 0);
}
