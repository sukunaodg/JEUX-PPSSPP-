#include <string.h>
#include "game.h"

Character g_characters[GAME_MAX_CHARACTERS];
int g_character_count = 0;

static void add_character(int id, const char *name, int hp, int chakra,
                          int attack, int defense, int speed)
{
    Character *c;
    if (g_character_count >= GAME_MAX_CHARACTERS)
        return;

    c = &g_characters[g_character_count++];
    memset(c, 0, sizeof(*c));
    c->id = id;
    strncpy(c->name, name, sizeof(c->name) - 1);
    c->max_health = hp;
    c->max_chakra = chakra;
    c->attack = attack;
    c->defense = defense;
    c->speed = speed;
    c->unlocked = 1;
}

void roster_init(void)
{
    g_character_count = 0;

    add_character(1, "Naruto Uzumaki", 1200, 1000, 115, 90, 100);
    add_character(2, "Sasuke Uchiha", 1100, 1000, 120, 85, 105);
    add_character(3, "Sakura Haruno", 1150, 700, 110, 105, 90);
    add_character(4, "Kakashi Hatake", 1050, 950, 112, 95, 100);
    add_character(5, "Itachi Uchiha", 1000, 1100, 125, 85, 105);
    add_character(6, "Madara Uchiha", 1400, 1200, 135, 115, 90);
    add_character(7, "Obito Uchiha", 1150, 1050, 118, 100, 95);
    add_character(8, "Pain", 1300, 1100, 120, 110, 85);
    add_character(9, "Minato Namikaze", 1050, 950, 118, 85, 120);
    add_character(10, "Hashirama Senju", 1450, 1150, 125, 125, 85);
    add_character(11, "Tsunade", 1250, 750, 120, 120, 80);
    add_character(12, "Gaara", 1150, 900, 105, 115, 85);
    add_character(13, "Rock Lee", 1100, 300, 125, 90, 115);
    add_character(14, "Jiraiya", 1200, 1000, 112, 100, 85);
    add_character(15, "Orochimaru", 1100, 1150, 115, 90, 95);
    add_character(16, "Killer Bee", 1250, 950, 120, 105, 90);
}

int roster_get(int index)
{
    if (index < 0 || index >= g_character_count)
        return -1;
    return index;
}

void roster_select_next(int direction)
{
    int index = g_game.progress.selected_character + direction;
    if (g_character_count <= 0)
        return;

    if (index < 0)
        index = g_character_count - 1;
    if (index >= g_character_count)
        index = 0;

    g_game.progress.selected_character = index;
}
