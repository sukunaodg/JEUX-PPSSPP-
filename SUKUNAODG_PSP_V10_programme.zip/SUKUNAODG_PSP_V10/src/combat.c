#include <stdio.h>
#include <string.h>
#include "game.h"

static int clamp_value(int value, int low, int high)
{
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

void combat_start(int player_index, int enemy_index)
{
    Character *p;
    Character *e;

    if (player_index < 0 || player_index >= g_character_count ||
        enemy_index < 0 || enemy_index >= g_character_count)
        return;

    p = &g_characters[player_index];
    e = &g_characters[enemy_index];

    memset(&g_game.combat, 0, sizeof(g_game.combat));
    g_game.combat.active = 1;
    g_game.combat.player_index = player_index;
    g_game.combat.enemy_index = enemy_index;
    g_game.combat.player_health = p->max_health;
    g_game.combat.enemy_health = e->max_health;
    g_game.combat.player_chakra = p->max_chakra;
    g_game.combat.enemy_chakra = e->max_chakra;
    g_game.combat.timer = 99 * 60;
    strncpy(g_game.combat.message, "Combat commence !", sizeof(g_game.combat.message) - 1);
    g_game.state = STATE_COMBAT;
}

void combat_player_attack(void)
{
    Character *p;
    Character *e;
    int damage;

    if (!g_game.combat.active)
        return;

    p = &g_characters[g_game.combat.player_index];
    e = &g_characters[g_game.combat.enemy_index];
    damage = p->attack - (e->defense / 3);
    if (g_game.combat.enemy_guarding)
        damage /= 3;
    if (damage < 1) damage = 1;

    g_game.combat.enemy_health -= damage;
    g_game.combat.combo_count++;
    snprintf(g_game.combat.message, sizeof(g_game.combat.message),
             "%s : attaque ! -%d PV", p->name, damage);
}

void combat_player_special(void)
{
    Character *p;
    Character *e;
    int damage;

    if (!g_game.combat.active)
        return;

    p = &g_characters[g_game.combat.player_index];
    e = &g_characters[g_game.combat.enemy_index];

    if (g_game.combat.player_chakra < 250) {
        strncpy(g_game.combat.message, "Pas assez de chakra !",
                sizeof(g_game.combat.message) - 1);
        return;
    }

    g_game.combat.player_chakra -= 250;
    damage = p->attack * 2 - (e->defense / 4);
    if (damage < 1) damage = 1;
    g_game.combat.enemy_health -= damage;
    g_game.combat.combo_count = 0;

    snprintf(g_game.combat.message, sizeof(g_game.combat.message),
             "Technique speciale ! -%d PV", damage);
}

void combat_player_guard(int enabled)
{
    g_game.combat.player_guarding = enabled;
}

void combat_update(void)
{
    Character *p;
    Character *e;
    int damage;

    if (!g_game.combat.active)
        return;

    p = &g_characters[g_game.combat.player_index];
    e = &g_characters[g_game.combat.enemy_index];

    g_game.combat.player_health =
        clamp_value(g_game.combat.player_health, 0, p->max_health);
    g_game.combat.enemy_health =
        clamp_value(g_game.combat.enemy_health, 0, e->max_health);
    g_game.combat.player_chakra =
        clamp_value(g_game.combat.player_chakra, 0, p->max_chakra);

    if (g_game.combat.enemy_health <= 0) {
        g_game.combat.active = 0;
        g_game.progress.wins++;
        g_game.combat.last_result = 1;
        strncpy(g_game.combat.message, "Victoire !", sizeof(g_game.combat.message) - 1);
        g_game.state = STATE_MISSION_RESULT;
        save_write();
        return;
    }

    if (g_game.combat.player_health <= 0) {
        g_game.combat.active = 0;
        g_game.combat.last_result = -1;
        strncpy(g_game.combat.message, "Defaite. Reessaie !",
                sizeof(g_game.combat.message) - 1);
        g_game.state = STATE_MISSION_RESULT;
        return;
    }

    /* IA provisoire : l'adversaire attaque a intervalles reguliers. */
    if ((g_game.frame % 90) == 0) {
        damage = e->attack - (p->defense / 3);
        if (g_game.combat.player_guarding)
            damage /= 3;
        if (damage < 1) damage = 1;
        g_game.combat.player_health -= damage;
        snprintf(g_game.combat.message, sizeof(g_game.combat.message),
                 "%s attaque : -%d PV", e->name, damage);
    }

    if (g_game.combat.player_chakra < p->max_chakra &&
        (g_game.frame % 30) == 0)
        g_game.combat.player_chakra++;
}
