#include <pspkernel.h>
#include <pspdebug.h>
#include "game.h"

PSP_MODULE_INFO("SUKUNAODG PSP", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    ui_init();
    game_init();

    while (g_game.running) {
        input_update();
        game_update();
        ui_render();
        sceKernelDelayThread(16667);
        g_game.frame++;
    }

    game_shutdown();
    sceKernelExitGame();
    return 0;
}
