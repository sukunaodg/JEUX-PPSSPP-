#include <string.h>
#include "game.h"

Game g_game;

void game_init(void)
{
    memset(&g_game, 0, sizeof(g_game));
    g_game.running = 1;
    g_game.state = STATE_TITLE;

    input_init();
    roster_init();
    missions_init();

    g_game.progress.health = 100;
    g_game.progress.chakra = 100;
    g_game.progress.selected_character = 0;
    g_game.progress.selected_mission = 0;

    if (!save_load()) {
        g_game.progress.wins = 0;
        g_game.progress.completed_missions = 0;
    }
}

void game_update(void)
{
    if (input_pressed(PSP_CTRL_START)) {
        if (g_game.state == STATE_COMBAT) {
            g_game.state = STATE_PAUSE;
            return;
        }
        if (g_game.state == STATE_PAUSE) {
            g_game.state = STATE_COMBAT;
            return;
        }
    }

    switch (g_game.state) {
    case STATE_TITLE:
        if (input_pressed(PSP_CTRL_CROSS))
            g_game.state = STATE_CHARACTER_SELECT;
        if (input_pressed(PSP_CTRL_CIRCLE))
            g_game.state = STATE_MISSION_RESULT;
        break;

    case STATE_CHARACTER_SELECT:
        if (input_pressed(PSP_CTRL_UP))
            roster_select_next(-1);
        if (input_pressed(PSP_CTRL_DOWN))
            roster_select_next(1);
        if (input_pressed(PSP_CTRL_CROSS))
            combat_start(g_game.progress.selected_character,
                         (g_game.progress.selected_character + 1) % g_character_count);
        if (input_pressed(PSP_CTRL_CIRCLE))
            g_game.state = STATE_TITLE;
        break;

    case STATE_COMBAT:
        if (input_pressed(PSP_CTRL_CROSS))
            combat_player_attack();
        if (input_pressed(PSP_CTRL_CIRCLE))
            combat_player_special();
        if (input_pressed(PSP_CTRL_SQUARE))
            combat_player_guard(1);
        else
            combat_player_guard(0);
        if (input_pressed(PSP_CTRL_TRIANGLE) && g_game.combat.player_chakra < 100)
            g_game.combat.player_chakra += 3;
        combat_update();
        break;

    case STATE_MISSION_RESULT:
        if (input_pressed(PSP_CTRL_CROSS)) {
            mission_complete_current();
            g_game.state = STATE_TITLE;
            save_write();
        }
        if (input_pressed(PSP_CTRL_CIRCLE))
            g_game.state = STATE_TITLE;
        break;

    case STATE_PAUSE:
        if (input_pressed(PSP_CTRL_CROSS))
            g_game.state = STATE_COMBAT;
        if (input_pressed(PSP_CTRL_CIRCLE)) {
            g_game.state = STATE_TITLE;
            g_game.combat.active = 0;
        }
        break;

    default:
        g_game.state = STATE_TITLE;
        break;
    }
}

void game_shutdown(void)
{
    save_write();
}
