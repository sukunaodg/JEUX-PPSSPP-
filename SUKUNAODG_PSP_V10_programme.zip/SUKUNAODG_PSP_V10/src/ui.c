#include <pspdebug.h>
#include "game.h"

void ui_init(void)
{
    pspDebugScreenInit();
}

void ui_render(void)
{
    Character *c;

    pspDebugScreenSetXY(0, 0);
    pspDebugScreenPrintf("========================================\n");
    pspDebugScreenPrintf("          SUKUNAODG PSP - V10           \n");
    pspDebugScreenPrintf("========================================\n\n");

    switch (g_game.state) {
    case STATE_TITLE:
        pspDebugScreenPrintf("MENU PRINCIPAL\n\n");
        pspDebugScreenPrintf("[CROIX] Selection des personnages\n");
        pspDebugScreenPrintf("[ROND] Missions / progression\n");
        pspDebugScreenPrintf("Victoires : %d\n", g_game.progress.wins);
        pspDebugScreenPrintf("Missions terminees : %d\n",
                             g_game.progress.completed_missions);
        break;

    case STATE_CHARACTER_SELECT:
        c = &g_characters[g_game.progress.selected_character];
        pspDebugScreenPrintf("SELECTION DU COMBATTANT\n\n");
        pspDebugScreenPrintf("Personnage : %s\n", c->name);
        pspDebugScreenPrintf("PV : %d | Chakra : %d\n", c->max_health, c->max_chakra);
        pspDebugScreenPrintf("Attaque : %d | Defense : %d | Vitesse : %d\n",
                             c->attack, c->defense, c->speed);
        pspDebugScreenPrintf("\n[HAUT/BAS] Changer\n[CROIX] Combattre\n[ROND] Retour\n");
        break;

    case STATE_COMBAT:
        pspDebugScreenPrintf("COMBAT\n\n");
        pspDebugScreenPrintf("%s : %d PV\n",
            g_characters[g_game.combat.player_index].name,
            g_game.combat.player_health);
        pspDebugScreenPrintf("Chakra : %d\n", g_game.combat.player_chakra);
        pspDebugScreenPrintf("\nVS\n\n");
        pspDebugScreenPrintf("%s : %d PV\n",
            g_characters[g_game.combat.enemy_index].name,
            g_game.combat.enemy_health);
        pspDebugScreenPrintf("\n%s\n", g_game.combat.message);
        pspDebugScreenPrintf("\n[CROIX] Attaque [ROND] Speciale\n");
        pspDebugScreenPrintf("[CARRE] Garde [TRIANGLE] Chakra [START] Pause\n");
        break;

    case STATE_MISSION_RESULT:
        pspDebugScreenPrintf("RESULTAT / MISSIONS\n\n");
        pspDebugScreenPrintf("%s\n", g_game.combat.message);
        pspDebugScreenPrintf("Missions terminees : %d\n",
                             g_game.progress.completed_missions);
        pspDebugScreenPrintf("\n[CROIX] Continuer [ROND] Menu\n");
        break;

    case STATE_PAUSE:
        pspDebugScreenPrintf("PAUSE\n\n[CROIX] Reprendre\n[ROND] Quitter le combat\n");
        break;

    default:
        pspDebugScreenPrintf("Etat inconnu.\n");
        break;
    }

    pspDebugScreenPrintf("\n\nVersion logicielle V10 - interface temporaire");
}
