#include <string.h>
#include "game.h"

Mission g_missions[GAME_MAX_MISSIONS];
int g_mission_count = 0;

static void add_mission(int id, const char *title, const char *objective,
                        int target, int reward)
{
    Mission *m;
    if (g_mission_count >= GAME_MAX_MISSIONS)
        return;

    m = &g_missions[g_mission_count++];
    memset(m, 0, sizeof(*m));
    m->id = id;
    strncpy(m->title, title, sizeof(m->title) - 1);
    strncpy(m->objective, objective, sizeof(m->objective) - 1);
    m->target = target;
    m->reward = reward;
    m->unlocked = (id == 1);
}

void missions_init(void)
{
    g_mission_count = 0;
    add_mission(1, "Premiers pas", "Gagner un combat d'entrainement", 1, 100);
    add_mission(2, "Rivalite", "Remporter trois combats", 3, 250);
    add_mission(3, "Maitrise du chakra", "Utiliser les techniques speciales", 5, 300);
    add_mission(4, "Ninja confirme", "Gagner cinq combats", 5, 500);
}

void mission_update(void)
{
    int i;
    for (i = 0; i < g_mission_count; i++) {
        if (i == 0 || g_missions[i - 1].completed)
            g_missions[i].unlocked = 1;
    }
}

void mission_complete_current(void)
{
    int index = g_game.progress.selected_mission;

    if (index < 0 || index >= g_mission_count)
        return;

    if (g_game.combat.last_result == 1 && !g_missions[index].completed) {
        g_missions[index].completed = 1;
        g_game.progress.completed_missions++;
        g_game.progress.health += g_missions[index].reward;
    }

    mission_update();
    save_write();
}
