# SUKUNAODG PSP — V10 architecture

Projet de jeu d'action Naruto destiné à la PSP et à l'émulateur PPSSPP.

## Contenu de cette version
- boucle principale PSP et états de jeu ;
- lecture des boutons de la manette ;
- roster de personnages extensible ;
- combat de base : attaque, défense, chakra et technique spéciale ;
- adversaire contrôlé par une IA simple ;
- missions et progression ;
- sauvegarde locale ;
- interface texte temporaire pour valider les systèmes avant les graphismes.

## Important
Cette version est une **base logicielle structurée**, pas un jeu complet. Elle n'inclut pas encore de modèles 3D, animations, textures, arènes, musiques ou effets finaux. Les personnages sont pour l'instant représentés par leurs données et une interface texte de test.

## Compilation
Installer un environnement PSPSDK compatible, ouvrir un terminal dans ce dossier et exécuter :

```sh
make
```

Le Makefile standard du PSPSDK produit `EBOOT.PBP`.

## Commandes de test
- Croix : lancer / confirmer / attaquer
- Rond : technique spéciale
- Carré : défendre
- Triangle : récupérer du chakra
- Start : revenir au menu / mettre en pause
- Haut / Bas : changer le personnage sélectionné

## Organisation
- `include/game.h` : structures et interfaces communes
- `src/main.c` : point d'entrée PSP et boucle principale
- `src/game.c` : état général et initialisation
- `src/input.c` : commandes PSP
- `src/roster.c` : données des combattants
- `src/combat.c` : logique du combat
- `src/mission.c` : missions et progression
- `src/save.c` : sauvegarde
- `src/ui.c` : interface temporaire de diagnostic

## Prochaine étape
Compiler et tester cette base avec le PSPSDK. Ensuite, compléter les systèmes et remplacer progressivement l'interface temporaire par le moteur graphique, puis intégrer les ressources Blender converties pour la PSP.
