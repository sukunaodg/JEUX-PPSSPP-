#ifndef SUKUNAODG_GAME_H
#define SUKUNAODG_GAME_H

#include <pspkernel.h>
#include <pspctrl.h>

#define GAME_MAX_CHARACTERS 64
#define GAME_MAX_MISSIONS 32
#define GAME_SAVE_PATH "ms0:/PSP/SAVEDATA/SUKUNAODG/SAVE.DAT"

typedef enum {
    STATE_TITLE = 0,
    STATE_CHARACTER_SELECT,
    STATE_COMBAT,
    STATE_MISSION_RESULT,
    STATE_PAUSE
} GameState;

typedef struct {
    int id;
    char name[40];
    int max_health;
    int max_chakra;
    int attack;
    int defense;
    int speed;
    int unlocked;
} Character;

typedef struct {
    int id;
    char title[64];
    char objective[96];
    int target;
    int reward;
    int unlocked;
    int completed;
} Mission;

typedef struct {
    int health;
    int chakra;
    int guard;
    int wins;
    int selected_character;
    int selected_mission;
    int completed_missions;
} PlayerProgress;

typedef struct {
    int active;
    int player_index;
    int enemy_index;
    int player_health;
    int enemy_health;
    int player_chakra;
    int enemy_chakra;
    int timer;
    int player_guarding;
    int enemy_guarding;
    int combo_count;
    int last_result;
    char message[80];
} CombatSession;

typedef struct {
    GameState state;
    SceCtrlData pad;
    PlayerProgress progress;
    CombatSession combat;
    int running;
    int frame;
    int input_lock;
} Game;

extern Game g_game;
extern Character g_characters[GAME_MAX_CHARACTERS];
extern int g_character_count;
extern Mission g_missions[GAME_MAX_MISSIONS];
extern int g_mission_count;

void game_init(void);
void game_update(void);
void game_shutdown(void);

void input_init(void);
void input_update(void);
int input_pressed(unsigned int buttons);

void roster_init(void);
int roster_get(int index);
void roster_select_next(int direction);

void combat_start(int player_index, int enemy_index);
void combat_update(void);
void combat_player_attack(void);
void combat_player_special(void);
void combat_player_guard(int enabled);

void missions_init(void);
void mission_update(void);
void mission_complete_current(void);

int save_load(void);
int save_write(void);

void ui_init(void);
void ui_render(void);

#endif
